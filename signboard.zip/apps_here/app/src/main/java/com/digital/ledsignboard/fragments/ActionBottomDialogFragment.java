package com.digital.ledsignboard.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.digital.ledsignboard.MainActivity;
import com.digital.ledsignboard.R;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class ActionBottomDialogFragment extends BottomSheetDialogFragment {

    public static final String TAG = "ActionBottomDialogFragment";

    public static ActionBottomDialogFragment newInstance() {
        return new ActionBottomDialogFragment();
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.boardtxt_bottom_sheet, container, false);
        initViews(view);
        return view;
    }

    public void initViews(View view){

        Button btn_show=view.findViewById(R.id.btn_show);
        Button btn_cancel=view.findViewById(R.id.btn_cancel);
        final EditText edit_txt=view.findViewById(R.id.edit_txt);

        btn_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str_txt=edit_txt.getText().toString().trim();
                if(!str_txt.isEmpty()){
                    ((MainActivity)getContext()).setBoardText(str_txt);
                    dismiss();
                }

            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

    }

    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setCancelable(false);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }




}
