package com.digital.ledsignboard;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.digital.ledsignboard.fragments.ActionBottomDialogFragment;
import com.jaredrummler.android.colorpicker.ColorPickerDialog;
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener;

public class MainActivity extends AppCompatActivity implements ColorPickerDialogListener {

    TextView txt_board, txt_board_sec, txt_change, txt_progress;
    Button btn_landscap;
    ImageView img_board;
    SeekBar seek_view;
    View board_bg_color, txt_bg_color;
    int color_view = 0;
    int currentColor_bg = Color.GRAY;
    int currentColor_txt = Color.RED;
    ColorPickerDialog.Builder builder;
    int duration = 10000;
    int maxDuration = 20000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);
        builder = ColorPickerDialog.newBuilder();
        initViews();
    }

    private void initViews() {
        btn_landscap = findViewById(R.id.btn_landscap);
        txt_progress = findViewById(R.id.txt_progress);
        seek_view = findViewById(R.id.seek_view);
        img_board = findViewById(R.id.img_board);
        board_bg_color = findViewById(R.id.board_bg_color);
        txt_bg_color = findViewById(R.id.txt_bg_color);
        txt_board = findViewById(R.id.txt_board);
        txt_board_sec = findViewById(R.id.txt_board_sec);
        txt_change = findViewById(R.id.txt_change);

        initFonts(txt_board);
        initFonts(txt_board_sec);
        setParamsOfBoardtxt();
        slideToLeft(txt_board);

        board_bg_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color_view = 1;
                builder.setColor(currentColor_bg).show(MainActivity.this);
            }
        });

        txt_bg_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color_view = 2;
                builder.setColor(currentColor_txt).show(MainActivity.this);

            }
        });

        txt_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActionBottomDialogFragment bottomSheetDialog = ActionBottomDialogFragment.newInstance();
                bottomSheetDialog.show(getSupportFragmentManager(), "Enter your text");
            }
        });

        seek_view.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                txt_progress.setText("" + progress);
                duration = maxDuration - (progress * 200);
                if (duration == 0) duration = 200;
                animation.setDuration(duration);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btn_landscap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String progress = txt_progress.getText().toString();

                Intent intent = new Intent(MainActivity.this, BoardLandScap_Activity.class);
                intent.putExtra("txt_speed", duration);
                intent.putExtra("board_bg", currentColor_bg);
                intent.putExtra("txt_bg", currentColor_txt);
                intent.putExtra("board_txt", txt_board.getText().toString());
                startActivity(intent);


              /* Intent recrItent= new Intent(MainActivity.this,ScreenRecoardingActivity.class);
               startActivity(recrItent);*/
            }
        });
    }

    ValueAnimator animation = null;

    public void slideToLeft(final View view) {
        animation = ValueAnimator.ofFloat(1.0f, 0.0f);
        animation.setRepeatCount(ValueAnimator.INFINITE);
        animation.setInterpolator(new LinearInterpolator());
        animation.setDuration(duration);
        animation.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                final float progress = (float) animation.getAnimatedValue();
                final float width = view.getWidth();
                final float translationX = width * progress;
                view.setTranslationX(translationX);
                txt_board_sec.setTranslationX(translationX - width);
            }
        });

        animation.start();

    }


    @Override
    public void onColorSelected(int dialogId, int newColor) {
        if (color_view == 1) {
            currentColor_bg = newColor;
            board_bg_color.setBackgroundColor(newColor);

            PorterDuffColorFilter porterDuffColorFilter = new PorterDuffColorFilter(newColor,
                    PorterDuff.Mode.SRC_ATOP);

            img_board.setColorFilter(porterDuffColorFilter);
        } else if (color_view == 2) {
            currentColor_txt = newColor;
            txt_bg_color.setBackgroundColor(newColor);
            txt_board.setTextColor(newColor);
            txt_board_sec.setTextColor(newColor);
        }
    }

    @Override
    public void onDialogDismissed(int dialogId) {

    }

    public void setBoardText(String txt) {
        txt_board.setText(txt);
        txt_board_sec.setText(txt);
        txt_board.clearAnimation();
        txt_board_sec.clearAnimation();
        setParamsOfBoardtxt();
        slideToLeft(txt_board);
    }

    private void initFonts(TextView tv) {
        Typeface face = Typeface.createFromAsset(getAssets(),
                "fonts/dotted.ttf");
        tv.setTypeface(face);

    }


    private void setParamsOfBoardtxt() {
        int len_txt = txt_board.length();
        int txtview_width = 0;
        if (len_txt <= 8) {
            txtview_width = len_txt * 120;
        }

        if (len_txt > 8 && len_txt <= 13) {
            txtview_width = len_txt * 110;
        } else if (len_txt > 13) {
            txtview_width = len_txt * 100;
        }

        txtview_width = (int)  (txtview_width * Resources.getSystem().getDisplayMetrics().density);
        int height = (int) (200 * Resources.getSystem().getDisplayMetrics().density);

        ViewGroup.LayoutParams params = txt_board.getLayoutParams();
        params.width = txtview_width;
        params.height = height;


        txt_board.setLayoutParams(params);
        txt_board_sec.setLayoutParams(params);

    }
}
