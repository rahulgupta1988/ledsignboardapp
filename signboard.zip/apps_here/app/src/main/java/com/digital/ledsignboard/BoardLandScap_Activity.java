package com.digital.ledsignboard;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class BoardLandScap_Activity extends AppCompatActivity {

    TextView txt_board, txt_board_sec;
    ImageView img_board;
    int txt_speed, board_bg, txt_bg;
    String txtStr;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.board_landscap);

        Intent intent = getIntent();
        txt_speed = intent.getIntExtra("txt_speed", 0);
        board_bg = intent.getIntExtra("board_bg", 0);
        txt_bg = intent.getIntExtra("txt_bg", 0);
        txtStr = intent.getStringExtra("board_txt");

        setViews();
    }

    private void setViews() {
        img_board = findViewById(R.id.img_board);
        txt_board = findViewById(R.id.txt_board);
        txt_board_sec = findViewById(R.id.txt_board_sec);

        txt_board.setText(txtStr);
        txt_board_sec.setText(txtStr);

        PorterDuffColorFilter porterDuffColorFilter = new PorterDuffColorFilter(board_bg,
                PorterDuff.Mode.SRC_ATOP);
        img_board.setColorFilter(porterDuffColorFilter);
        txt_board.setTextColor(txt_bg);
        txt_board_sec.setTextColor(txt_bg);

        initFonts(txt_board);
        initFonts(txt_board_sec);
        setParamsOfBoardtxt();
        slideToLeft(txt_board);
    }

    ValueAnimator animation = null;


    public void slideToLeft(final View view) {
        animation = ValueAnimator.ofFloat(1.0f, 0.0f);
        animation.setRepeatCount(ValueAnimator.INFINITE);
        animation.setInterpolator(new LinearInterpolator());
        animation.setDuration(txt_speed);
        animation.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                final float progress = (float) animation.getAnimatedValue();
                final float width = view.getWidth();
                final float translationX = width * progress;
                view.setTranslationX(translationX);
                txt_board_sec.setTranslationX(translationX - width);
            }
        });

        animation.start();


    }


    private void initFonts(TextView tv) {
        Typeface face = Typeface.createFromAsset(getAssets(),
                "fonts/dotted.ttf");
        tv.setTypeface(face);

    }


    private void setParamsOfBoardtxt() {
        int len_txt = txt_board.length();
        int txtview_width = 0;
        if (len_txt <= 8) {
            txtview_width = len_txt * 190;
        }

        if (len_txt > 8 && len_txt <= 13) {
            txtview_width = len_txt * 180;
        } else if (len_txt > 13) {
            txtview_width = len_txt * 170;
        }

        txtview_width = (int) (int) (txtview_width * Resources.getSystem().getDisplayMetrics().density);
        // int height = (int) (200 * Resources.getSystem().getDisplayMetrics().density);

        ViewGroup.LayoutParams params = txt_board.getLayoutParams();
        params.width = txtview_width;
        //    params.height = height;


        txt_board.setLayoutParams(params);
        txt_board_sec.setLayoutParams(params);

    }
}
